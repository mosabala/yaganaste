package es.springboot.myweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudWithJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
