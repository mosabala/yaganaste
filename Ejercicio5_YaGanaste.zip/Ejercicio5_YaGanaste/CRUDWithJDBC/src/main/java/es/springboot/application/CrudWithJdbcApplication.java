package es.springboot.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudWithJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudWithJdbcApplication.class, args);
	}

}
