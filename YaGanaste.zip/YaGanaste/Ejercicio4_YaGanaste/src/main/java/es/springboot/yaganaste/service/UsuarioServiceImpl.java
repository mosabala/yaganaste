package es.springboot.yaganaste.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.springboot.yaganaste.model.Usuario;
import es.springboot.yaganaste.repository.UsuarioRepository;

@Service
public class UsuarioServiceImpl implements UsuarioService{
	@Autowired
	  UsuarioRepository usuarioADO;

	@Override
	public List<Usuario> getUsuarios(){
		List<Usuario> usuarioLst = new ArrayList();		
		usuarioADO.findAll().forEach(usuarioLst::add);
		return usuarioLst;		
	}
}
