package es.springboot.yaganaste.model;

public class Usuario {
	private String userName;
	private String pass;
	private Integer enable;
	
	public Usuario() {
		
	}
	
	public Usuario(String userName, String pass, Integer enable) {
		super();
		this.userName = userName;
		this.pass = pass;
		this.enable = enable;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Integer getEnable() {
		return enable;
	}
	public void setEnable(Integer enable) {
		this.enable = enable;
	}

	@Override
	public String toString() {
		return "Usuario [userName=" + userName + ", pass=" + pass + ", enable=" + enable + "]";
	}
	
}
