package es.springboot.yaganaste.repository;

import java.util.List;

import es.springboot.yaganaste.model.Usuario;

public interface UsuarioRepository {
	List<Usuario> findAll();
}
