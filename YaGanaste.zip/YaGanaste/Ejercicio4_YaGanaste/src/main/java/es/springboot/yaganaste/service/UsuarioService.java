package es.springboot.yaganaste.service;

import java.util.List;

import es.springboot.yaganaste.model.Usuario;

public interface UsuarioService {
	List<Usuario> getUsuarios();
}
