package es.springboot.yaganaste.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import es.springboot.yaganaste.model.Usuario;

@Repository
public class UsuarioRepositoryImpl implements UsuarioRepository{
	@Autowired
	  private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<Usuario> findAll() {
	    return jdbcTemplate.query("SELECT * from ya_ganaste.users", BeanPropertyRowMapper.newInstance(Usuario.class));
	}
	
	

}
