--SCRIPT MIGRACION DE BASE DE DATOS

USE [YAGANASTE]
GO

/****** Object:  Table [dbo].[PROVINCIA]    Script Date: 23/8/2023 11:50:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PROVINCIA](
	[IDPROVINCIA] [int] IDENTITY(1,1) NOT NULL,
	[DESCRIPCION] [varchar](255) NOT NULL,
 CONSTRAINT [PK_PROVINCIA] PRIMARY KEY CLUSTERED 
(
	[IDPROVINCIA] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
------------------------------------------------------------------
CREATE TABLE [dbo].[PRODUCTOS](
	[IDPRODUCTO] [char](1) NOT NULL,
	[DESCRIPCION] [varchar](255) NOT NULL,
	[PRECIO] [decimal](10, 2) NULL,
 CONSTRAINT [PK_PRODUCTOS] PRIMARY KEY CLUSTERED 
(
	[IDPRODUCTO] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
------------------------------------------------------------------
CREATE TABLE [dbo].[CLIENTES](
	[IDCLIENTE] [int] IDENTITY(1,1) NOT NULL,
	[NOMBRE] [varchar](255) NOT NULL,
	[IDPROVINCIA] [int] NOT NULL,
 CONSTRAINT [PK_CLIENTES] PRIMARY KEY CLUSTERED 
(
	[IDCLIENTE] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
------------------------------------------------------------------
CREATE TABLE [dbo].[COMPRAS](
	[IDCOMPRA] [int] IDENTITY(1,1) NOT NULL,
	[IDCLIENTE] [int] NULL,
	[IDPRODUCTO] [char](1) NULL,
	[FECHA] [datetime] NULL,
 CONSTRAINT [PK_COMPRAS] PRIMARY KEY CLUSTERED 
(
	[IDCOMPRA] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
------------------------------------------------------------------
INSERT INTO PROVINCIA (DESCRIPCION)VALUES('Zaragoza');
INSERT INTO PROVINCIA (DESCRIPCION)VALUES('Huesca');
INSERT INTO PROVINCIA (DESCRIPCION)VALUES('Teruel');

SELECT * FROM PROVINCIAS
-------------------------------------------------------------------
INSERT INTO PRODUCTOS (IDPRODUCTO, DESCRIPCION, PRECIO)VALUES('A',	'Playmobil', 5.00);
INSERT INTO PRODUCTOS (IDPRODUCTO, DESCRIPCION, PRECIO)VALUES('B',	'Puzzle', 10.25);
INSERT INTO PRODUCTOS (IDPRODUCTO, DESCRIPCION, PRECIO)VALUES('C',	'Peonza', 3.65);
SELECT * FROM PRODUCTOS
-------------------------------------------------------------------

INSERT INTO CLIENTES (NOMBRE, IDPROVINCIA) VALUES('Juan Palomo',	1);
INSERT INTO CLIENTES (NOMBRE, IDPROVINCIA) VALUES('Armando Ruido',	2);
INSERT INTO CLIENTES (NOMBRE, IDPROVINCIA) VALUES('Carmelo Cot�n',	1);
INSERT INTO CLIENTES (NOMBRE, IDPROVINCIA) VALUES('Dolores Fuertes',	3);
INSERT INTO CLIENTES (NOMBRE, IDPROVINCIA) VALUES('Alberto Mate',	3);
SELECT * FROM CLIENTES
-------------------------------------------------------------------
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (1,	'C',	'2022-01-01');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (2,	'B',	'2022-01-15');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (2,	'C',	'2022-01-22');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (4,	'A',	'2022-02-03');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (3,	'A',	'2022-02-05');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (1,	'B',	'2022-02-16');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (1,	'B',	'2022-02-21');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (4,	'A',	'2022-02-21');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (5,	'C',	'2022-03-01');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (3,	'A',	'2022-03-01');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (3,	'C',	'2022-03-05');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (2,	'B',	'2022-03-07');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (2,	'B',	'2022-03-11');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (1,	'A',	'2022-03-18');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (1,	'C',	'2022-03-29');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (5,	'B',	'2022-04-08');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (5,	'C',	'2022-04-09');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (4,	'C',	'2022-04-09');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (1,	'A',	'2022-04-12');
INSERT INTO COMPRAS (IDCLIENTE,	IDPRODUCTO,	FECHA) VALUES (2,	'A',	'2022-04-19');
SELECT * FROM COMPRAS
-------------------------------------------------------------------
--Crear las consultas SQL necesarias para obtener los siguientes datos:

--1.	Todas las compras detalladas con los datos del cliente, de los productos y de cada una de las ventas (c�digo de cliente, nombre de cliente, nombre de provincia, producto, importe, fecha de la venta)

SELECT cl.IDCLIENTE as [c�digo de cliente],
cl.NOMBRE as [nombre de cliente],
pr.DESCRIPCION as [nombre de provincia],
p.DESCRIPCION as producto,
p.PRECIO as importe, 
c.FECHA as [fecha de la venta]
FROM COMPRAS c
INNER JOIN CLIENTES cl
ON c.IDCLIENTE = cl.IDCLIENTE
INNER JOIN PROVINCIAS pr
ON cl.IDPROVINCIA = pr.IDPROVINCIA
INNER JOIN PRODUCTOS p
ON c.IDPRODUCTO = p.IDPRODUCTO


--2.	Las compras detalladas de los clientes de Teruel.
SELECT cl.IDCLIENTE as [c�digo de cliente],
cl.NOMBRE as [nombre de cliente],
pr.DESCRIPCION as [nombre de provincia],
p.DESCRIPCION as producto,
p.PRECIO as importe, 
c.FECHA as [fecha de la venta]
FROM COMPRAS c
INNER JOIN CLIENTES cl
ON c.IDCLIENTE = cl.IDCLIENTE
INNER JOIN PROVINCIAS pr
ON cl.IDPROVINCIA = pr.IDPROVINCIA
INNER JOIN PRODUCTOS p
ON c.IDPRODUCTO = p.IDPRODUCTO
WHERE 
pr.DESCRIPCION = 'Teruel'


--3.	Las compras detalladas de los clientes de Huesca y Zaragoza en el primer trimestre de 2015
SELECT cl.IDCLIENTE as [c�digo de cliente],
cl.NOMBRE as [nombre de cliente],
pr.DESCRIPCION as [nombre de provincia],
p.DESCRIPCION as producto,
p.PRECIO as importe, 
c.FECHA as [fecha de la venta]
FROM COMPRAS c
INNER JOIN CLIENTES cl
ON c.IDCLIENTE = cl.IDCLIENTE
INNER JOIN PROVINCIAS pr
ON cl.IDPROVINCIA = pr.IDPROVINCIA
INNER JOIN PRODUCTOS p
ON c.IDPRODUCTO = p.IDPRODUCTO
WHERE 
pr.DESCRIPCION IN('Huesca','Zaragoza')
AND c.FECHA BETWEEN '2015-01-01' AND '2015-03-31'


--4. Las compras agrupadas por producto de todos los clientes 
--mostrando el n�mero de compras y el importe total para cada producto por cada uno de los clientes (c�digo de cliente, provincia, producto, n�mero de ventas, importe total)

-- Evidentemente el enunciado es ambiguo y no se entiende si hay que agrupar
--en base los productos vendidos � en base a la cantidad de productos comprados por cada cliente

--Tomar� en cuenta los siguientes campos
--c�digo de cliente, provincia, producto, n�mero de ventas, importe total

SELECT
cl.IDCLIENTE as [c�digo de cliente],
pr.DESCRIPCION as provincia,
p.DESCRIPCION as producto,
COUNT(1) as [n�mero de ventas],
SUM(p.PRECIO) as [importe total]

FROM COMPRAS c
INNER JOIN CLIENTES cl
ON c.IDCLIENTE = cl.IDCLIENTE
INNER JOIN PROVINCIAS pr
ON cl.IDPROVINCIA = pr.IDPROVINCIA
INNER JOIN PRODUCTOS p
ON c.IDPRODUCTO = p.IDPRODUCTO

GROUP BY 
cl.IDCLIENTE,
p.DESCRIPCION,
pr.DESCRIPCION


--5.	N�mero de peonzas totales que se han comprado en el mes de marzo por los clientes de Zaragoza 
(n�mero de peonzas e importe total)


SELECT 
	count(1) as [n�mero de peonzas],
	SUM(TC.PRECIO) as [importe total] 
	FROM
	(SELECT 
	p.DESCRIPCION,
	p.PRECIO, 
	c.FECHA
	FROM COMPRAS c
	INNER JOIN PRODUCTOS p
	ON c.IDPRODUCTO = p.IDPRODUCTO
	INNER JOIN CLIENTES cl
	ON c.IDCLIENTE = cl.IDCLIENTE
	INNER JOIN PROVINCIAS pr
	ON cl.IDPROVINCIA = pr.IDPROVINCIA


	WHERE
	p.DESCRIPCION='Peonza'
	AND pr.DESCRIPCION='Zaragoza'
	AND MONTH(c.FECHA)= 3) as TC

GROUP BY
TC.DESCRIPCION


--6.	Las compras realizadas por todos los clientes agrupadas por mes
--(c�digo de cliente, nombre, provincia, mes, n�mero de compras, importe total)


SELECT cl.IDCLIENTE,
	cl.NOMBRE,
	pr.DESCRIPCION,
	p.PRECIO,
	MONTH(c.FECHA) as Mes,
	COUNT(1) as [n�mero de compras],
	SUM(p.PRECIO) as [importe total]

	FROM COMPRAS c
	INNER JOIN CLIENTES cl
	ON c.IDCLIENTE = cl.IDCLIENTE
	INNER JOIN PROVINCIAS pr
	ON cl.IDPROVINCIA = pr.IDPROVINCIA
	INNER JOIN PRODUCTOS p
	ON c.IDPRODUCTO = p.IDPRODUCTO

GROUP BY
cl.IDCLIENTE,
	cl.NOMBRE,
	pr.DESCRIPCION,
	p.PRECIO,
	MONTH(c.FECHA)


--7. Detalle de todas las ventas agrupadas por d�a del mes 
--(d�a del mes, producto, n�mero de compras, importe total). 
--Por ejemplo, los d�as 1 de enero, febrero, marzo y abril se agrupar�n como d�a del mes 1

SELECT 
DAY(c.FECHA) as [Dia del Mes],
p.DESCRIPCION as producto,
count(1) as [n�mero de compras],
SUM(p.PRECIO) as [importe total]

FROM COMPRAS c
INNER JOIN PRODUCTOS p
ON c.IDPRODUCTO = p.IDPRODUCTO

GROUP BY
DAY(c.FECHA),
p.DESCRIPCION,
p.PRECIO
